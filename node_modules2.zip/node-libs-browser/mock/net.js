exports.createServer =
exports.createConnection =
exports.connect =
function () {};

exports.isIP =
exports.isIPv4 =
exports.isIPv6 =
function () { return true };

